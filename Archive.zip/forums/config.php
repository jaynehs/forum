<?php

$db_type = 'mysqli_innodb';
$db_host = 'localhost';
$db_name = 'database';
$db_username = 'gamesense';
$db_password = 'Gamesenseniggaballs123!@#';
$db_prefix = 'gs_';
$p_connect = false;

$cookie_name = 'pun_cookie_2a0439';
$cookie_domain = '';
$cookie_path = '/';
$cookie_secure = 0;
$cookie_seed = '29f615ba38d74704';

define('PUN', 1);
