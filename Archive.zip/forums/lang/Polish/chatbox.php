<?php

// Language definitions used in chatbox.php
$lang_chatbox = array(

'Page_title'				=>	'ChatBox',
'Chatbox'					=>	'ChatBox',
'Posts'						=>	' wiadomości',
'Sending'					=>	'Wysyłanie...',

'No Read Permission'		=>	'Nie masz uprawnień, aby czytać ChatBox.',
'No Post Permission'		=>	'Nie masz uprawnień, aby pisać na ChatBox\'ie.',
'No Message'				=>	'Brak wiadomości w ChatBox\'ie.',

'Message'					=>	'Wiadomość',
'Btn Send'					=>	'Wyślij',

'Error Title'				=>	'Błąd',
'Error No message'			=>	'Musisz wpisać wiadomośc.',
'Error Too long message'	=>	'Wiadomość jest zbyt długa.',

);
