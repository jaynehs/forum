<?php

$lang_apmsn = array(

'Plugin title' => 'PMS New - New Private Messaging System',
'Explanation 1'	=> 'This plugin allows configuring private messaging system (PMS) for your forum.',
'Explanation 2'	=> 'You can turn on or off PMS and limit number of messages in folders (Set to 0 to disable limit).',
'Form title' => 'Options',
'Show text button' => 'Save changes',
'Plugin redirect' => 'Options updated. Redirecting …',
'Group' => 'Group',
'Kolvo' => 'Box capacity',
'Allow' => 'Allow PMS',
'Legend1' => 'Global options',
'Legend2' => 'Group options',
'Legend3' => 'Additional options',
'Q1' => 'Enable PMS.',
'Q3' => 'Minimum number of posts a user must have made to send private messages.',
'Q2' => 'For notification of new private messages, use <span class="remflasher">&#160;</span> instead of popup window.',

);
