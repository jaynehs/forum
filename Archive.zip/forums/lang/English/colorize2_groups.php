<?php

$lang_colorize2_groups = array(
'Group color'			=> 'Group color',
'Group color help'		=> 'Set group color. Leave blank to use default color.',
'Inalid color message'	=> 'You entered an invalid color.',

'Legend'				=> 'Legend',
);
