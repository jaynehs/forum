<?php

// Language definitions used by Like mod

$lang_like_mod = array(
	'Like'						=>	'J\'aime',
	'Unlike'					=>	'Je n\'aime plus',
	'Like this post'			=>	'Aime ce post:',
	'Like this post multiple'	=>	'Aiment ce post:',
	'Like registered'			=>	'J\'aime enregistr�',
	'Self like'					=>	'Vous ne pouvez pas aimer vos propres messages.',
);