<?php

// Language definitions used by Like mod

$lang_like_mod = array(
	'Like'		                =>	'Vind ik leuk',
	'Unlike'	                =>	'Vind ik niet meer leuk',
	'Like this post'	        =>	'Vinden dit leuk:',
	'Like this post multiple'	=>	'Vinden dit leuk:',
	'Like registered'	        =>	'Vind ik leuk',
	'Self like'	                =>	'Eigen post leuk vinden is niet toegestaan.',
);