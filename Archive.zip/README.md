# secure-gamesense-forum

This forum is a secure gamesense forum, made by me so you guys can stop being gamesense forum fanboys. It's 100% secure and open source, open up your own forum with it only thing that needs to be done is to add a chatbox. It's a fluxbb based forum so i would recommend ajaxchat (https://github.com/Frug/AJAX-Chat) for 100% working shoutbox on the forum.
Please consider to drop a follow to my github page
